/*
 * timer0.h
 *
 * Created: 2/15/2023 6:50:52 AM
 *  Author: abdel
 */ 


#ifndef TIMER0_H_
#define TIMER0_H_


void timer_ctc_init_interrupt(void);
void timer2_overflow_init_interrupt(void);



#endif /* TIMER0_H_ */