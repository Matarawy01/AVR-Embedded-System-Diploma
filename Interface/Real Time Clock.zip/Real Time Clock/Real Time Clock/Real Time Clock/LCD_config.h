/*
 * LCD_config.h
 *
 * Created: 12/1/2022 2:56:20 PM
 *  Author: abdel
 */ 


#ifndef LCD_CONFIG_H_
#define LCD_CONFIG_H_
#define four_bits_mode
#endif /* LCD_CONFIG_H_ */