/*
 * keypad_driver.h
 *
 * Created: 12/13/2022 4:56:01 PM
 *  Author: abdel
 */ 


#ifndef KEYPAD_DRIVER_H_
#define KEYPAD_DRIVER_H_
#include "DIO_driver.h"
#define NOTPASSED 0XFF 
void keypad_vinit();
unsigned char keypad_u8read();


#endif /* KEYPAD_DRIVER_H_ */