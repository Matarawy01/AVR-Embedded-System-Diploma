/*
 * _7seg_driver.h
 *
 * Created: 10/8/2022 1:35:02 PM
 *  Author: abdel
 */ 


#ifndef seven_SEG_DRIVER_H_
#define seven_SEG_DRIVER_H_

void seven_seg_vinit(unsigned char port);
void seven_seg_write(unsigned char port,unsigned char number);



#endif /* SEVEN_SEG_DRIVER_H_ */